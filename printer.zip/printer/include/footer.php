    <footer>
        <p>&copy; <?php echo date("Y"); ?> Shri Ganga Ram Enterprises - All Rights Reserved</p>
        <p><small>Powered by Printer Vala</small></p>
    </footer>