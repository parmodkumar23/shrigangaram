<header>
        <div class="logo"><img src="images/logo.png"/></div>
        <div class="hamburger" onclick="toggleMenu()"><i class="fas fa-bars"></i></div>
        <ul class="nav-links" id="navLinks">
            <li><a href="#">Home</a></li>
            <li><a href="about.php">About Us</a></li>
            <li><a href="#">Products</a></li>
            <li><a href="#">Services</a></li>
            <li><a href="#">Contact</a></li>
        </ul>
    </header>